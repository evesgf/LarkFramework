﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameEntry : MonoBehaviour
{
    Dictionary<GameObject, string> list = new Dictionary<GameObject, string>();

    // Use this for initialization
    void Start()
    {
        ResManager.Create().Init(delegate
        {
            Debug.Log("资源初始化完成");
        });
    }

    // Update is called once per frame
    void Update()
    {
        //同步加载预置件
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            var abName = "Prefabs/prefab.unity3d";
            var assetName = "Assets/_Project/Prefabs/Cube01.prefab";
            var reObj = ResManager.Instance.LoadPrefab(abName, assetName);
            var gameObj=Instantiate(reObj);
            list.Add(gameObj, abName);
        }

        //异步加载预置件
        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            var abName = "Prefabs/prefab.unity3d";
            var assetName = "Assets/_Project/Prefabs/Cube01.prefab";
            StartCoroutine(ResManager.Instance.LoadPrefabAsync(abName, assetName, delegate (GameObject reObj)
            {
                var gameObj = Instantiate(reObj);
                list.Add(gameObj, abName);
            }));
        }


        if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            var abName = "Scenes/scene.unity3d";
            var assetName = "Assets/_Project/Scenes/Home.unity";

            StartCoroutine(ResManager.Instance.LoadSceneAsync(abName, assetName, delegate
            {
                Debug.Log("场景加载完成!");
            }));
        }

        //卸载Prefab
        if (Input.GetKeyDown(KeyCode.Alpha4))
        {
            foreach (var item in list)
            {
                Destroy(item.Key);
                ResManager.Instance.UnLoadAssetBundle(item.Value, true);
                list.Remove(item.Key);
                return;
            }
        }
    }
}
